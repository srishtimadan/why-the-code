# Why The Code Is Like This

Answers "why is this the way it is?" for a real codebase, with a chain of evidence for every answer.
It builds a **Neo4j AuraDB knowledge graph** (code entities <-> decisions <-> people <-> incidents),
retrieves with **GraphRAG**, detects **superseded decisions**, shows a **confidence signal** and **refuses to invent** answers.

## Graph model
- `(:Person)-[:AUTHORED]->(:Source)` where Source is also `:Commit | :PR | :Issue | :Doc`
- `(:Source)-[:CHANGED]->(:Entity {kind: file|function|module|config})`
- `(:Commit)-[:PART_OF]->(:PR)`, `(:Commit)-[:FIXES|REFERENCES]->(:Issue {is_incident})`
- `(:Decision)-[:DECIDED_IN]->(:Source)`, `-[:MADE_BY]->(:Person)`, `-[:AFFECTS]->(:Entity)`, `-[:TRIGGERED_BY]->(:Issue)`
- `(:Decision)-[:SUPERSEDES {reason}]->(:Decision)` (older one gets `status='superseded'`)

## Run it
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                    # fill in AuraDB + LLM credentials
git clone https://github.com/psf/requests               # any large repo with a long, messy history
python ingest.py ./requests --github psf/requests --max-commits 500
python extract.py --limit 300                           # LLM extracts decisions, finds supersession
python ask.py "Why does requests strip the Authorization header on redirects?"
streamlit run app.py                                    # web UI
```
Set `GITHUB_TOKEN` to ingest PR/issue discussions without hitting rate limits. Without `--github`, only git history and in-repo docs are used.
For the Sarvam track, point `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL` at an OpenAI-compatible Sarvam endpoint (see their docs).

## How honesty works
1. Retrieval is graph-first (entity + decision fulltext, then traversal across SUPERSEDES edges).
2. The LLM may only use the retrieved evidence JSON and must return `answerable:false` if it does not answer the question.
3. No evidence or `answerable:false` -> explicit refusal. Otherwise confidence is derived from evidence count, entity match and whether sources carry a link and a person.
