"""Step 1: load commits, PRs, issues and design docs into Neo4j.
Usage: python ingest.py <local-clone> [--github owner/repo] [--max-commits 500]"""
import argparse, os, re, subprocess, pathlib, requests
from common import run, ensure_schema

SEP, F = "\x1e", "\x1f"
REF = re.compile(r"#(\d+)")
FIX = re.compile(r"(?:fix(?:es|ed)?|close[sd]?|resolve[sd]?)\s+#(\d+)", re.I)
INCIDENT_LABELS = {"bug", "incident", "outage", "regression", "security"}
DOC_HINTS = ("docs", "doc", "adr", "rfc", "design", "decisions", "architecture")


def git_log(repo, n):
    fmt = f"--pretty=format:{SEP}%H{F}%an{F}%ae{F}%aI{F}%s{F}%b{F}"
    out = subprocess.run(["git", "-C", repo, "log", f"-{n}", "--name-only", fmt],
                         capture_output=True, text=True, check=True).stdout
    for rec in out.split(SEP)[1:]:
        h, an, ae, d, s, b, files = rec.split(F, 6)
        yield dict(sha=h, name=an, email=ae, date=d, msg=(s + "\n" + b).strip(),
                   files=[f.strip() for f in files.splitlines() if f.strip()])


def gh(slug, path, token):
    hdr = {"Authorization": f"Bearer {token}"} if token else {}
    r = requests.get(f"https://api.github.com/repos/{slug}/{path}", headers=hdr, timeout=30)
    return r.json() if r.ok else None


def save_commit(c):
    run("""
    MERGE (s:Source {sid:$sid}) SET s:Commit, s.text=$msg, s.title=split($msg,'\n')[0],
        s.date=datetime($date), s.url=$url
    MERGE (p:Person {id:$email}) SET p.name=$name
    MERGE (p)-[:AUTHORED]->(s)
    WITH s UNWIND $files AS f
    MERGE (e:Entity {key:'file:'+f}) SET e.name=f, e.kind='file'
    MERGE (s)-[:CHANGED]->(e)""",
        sid="commit:" + c["sha"], msg=c["msg"][:6000], date=c["date"], url=c.get("url", ""),
        email=c["email"], name=c["name"], files=c["files"][:50])


def save_thread(sid, label, j, text, rel, sha, incident):
    run(f"""
    MERGE (s:Source {{sid:$sid}}) SET s:{label}, s.title=$title, s.text=$text,
        s.date=datetime($date), s.url=$url, s.number=$n, s.is_incident=$inc
    WITH s MATCH (c:Source {{sid:$csid}}) MERGE (c)-[:{rel}]->(s)
    WITH s MERGE (p:Person {{id:$pid}}) SET p.name=$pname MERGE (p)-[:AUTHORED]->(s)""",
        sid=sid, title=j["title"], text=text[:6000], date=j["created_at"], url=j["html_url"],
        n=j["number"], inc=incident, csid="commit:" + sha,
        pid="gh:" + (j.get("user") or {}).get("login", "unknown"),
        pname=(j.get("user") or {}).get("login", "unknown"))


def ingest_threads(c, slug, token, seen):
    fixes = set(FIX.findall(c["msg"]))
    for n in set(REF.findall(c["msg"])):
        j = gh(slug, f"issues/{n}", token)
        if not j or "title" not in j:
            continue
        comments = gh(slug, f"issues/{n}/comments", token) or []
        text = j["title"] + "\n" + (j.get("body") or "") + "\n" + "\n".join(
            x.get("body", "") for x in comments if isinstance(x, dict))
        if "pull_request" in j:
            reviews = gh(slug, f"pulls/{n}/comments", token) or []
            text += "\n" + "\n".join(x.get("body", "") for x in reviews if isinstance(x, dict))
            save_thread(f"pr:{n}", "PR", j, text, "PART_OF", c["sha"], False)
        else:
            labels = {l["name"].lower() for l in j.get("labels", [])}
            inc = bool(labels & INCIDENT_LABELS)
            save_thread(f"issue:{n}", "Issue", j, text, "FIXES" if n in fixes else "REFERENCES",
                        c["sha"], inc)


def ingest_docs(repo):
    root = pathlib.Path(repo)
    for p in root.rglob("*.md"):
        rel = p.relative_to(root).as_posix()
        if ".git/" in rel or not any(h in rel.lower() for h in DOC_HINTS):
            continue
        date = subprocess.run(["git", "-C", repo, "log", "-1", "--format=%aI", "--", rel],
                              capture_output=True, text=True).stdout.strip()
        if not date:
            continue
        run("""MERGE (s:Source {sid:$sid}) SET s:Doc, s.title=$rel, s.text=$text,
               s.date=datetime($date), s.url=$rel""",
            sid="doc:" + rel, rel=rel, text=p.read_text(errors="ignore")[:6000], date=date)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("repo")
    ap.add_argument("--github")
    ap.add_argument("--max-commits", type=int, default=500)
    a = ap.parse_args()
    ensure_schema()
    token = os.getenv("GITHUB_TOKEN")
    for i, c in enumerate(git_log(a.repo, a.max_commits), 1):
        if a.github:
            c["url"] = f"https://github.com/{a.github}/commit/{c['sha']}"
        save_commit(c)
        if a.github:
            ingest_threads(c, a.github, token, set())
        if i % 50 == 0:
            print(f"ingested {i} commits")
    ingest_docs(a.repo)
    print("done")
