"""Step 3: GraphRAG question answering with evidence, supersession and refusal.
Usage: python ask.py "Why is the retry limit three?" """
import re, sys, json
from common import run, chat_json

STOP = {"why", "the", "what", "how", "does", "did", "this", "that", "was", "are", "and", "for", "with", "which", "who"}

ANSWER_SYS = """You answer 'why is the code like this?' using ONLY the evidence JSON provided.
Rules: (1) Never use outside knowledge or guess. (2) If a decision has 'superseded_by' entries, the superseded
decision is no longer current: say the newer one governs. (3) Name the decision, the discussion/commit that produced it,
the person to ask and the date. (4) If the evidence does not actually answer the question, reply {"answerable":false}.
Reply JSON only: {"answerable":true|false,"answer":"...","cited_ids":["..."]}"""


def lucene(q):
    words = [w for w in re.findall(r"[A-Za-z0-9_.]+", q) if len(w) > 2 and w.lower() not in STOP]
    return " OR ".join(re.sub(r'([+\-&|!(){}\[\]^"~*?:\\/])', r"\\\1", w) for w in words)


def retrieve(question):
    q = lucene(question)
    if not q:
        return [], False
    ent = run("""CALL db.index.fulltext.queryNodes('entityName',$q) YIELD node, score WHERE score > 0.5
                 MATCH (node)<-[:AFFECTS]-(d:Decision) RETURN d.id AS id, score ORDER BY score DESC LIMIT 5""", q=q)
    dec = run("""CALL db.index.fulltext.queryNodes('decisionText',$q) YIELD node, score
                 RETURN node.id AS id, score ORDER BY score DESC LIMIT 5""", q=q)
    ids = list(dict.fromkeys([r["id"] for r in ent + dec]))[:8]
    if not ids:
        return [], False
    # Expand: also pull decisions that supersede / are superseded by the hits (graph traversal)
    ev = run("""
        MATCH (d:Decision) WHERE d.id IN $ids
        OPTIONAL MATCH (d)-[:SUPERSEDES*0..1]-(x:Decision)
        WITH collect(DISTINCT d) + collect(DISTINCT x) AS all UNWIND all AS d
        WITH DISTINCT d WHERE d IS NOT NULL
        OPTIONAL MATCH (d)-[:DECIDED_IN]->(s:Source)
        OPTIONAL MATCH (d)-[:MADE_BY]->(p:Person)
        OPTIONAL MATCH (d)-[:SUPERSEDES]->(old:Decision)
        OPTIONAL MATCH (new:Decision)-[:SUPERSEDES]->(d)
        OPTIONAL MATCH (d)-[:TRIGGERED_BY]->(i:Issue)
        RETURN d.id AS id, d.summary AS summary, d.rationale AS rationale, toString(d.date) AS date,
               d.status AS status, s.title AS source, s.url AS url, p.name AS person,
               collect(DISTINCT old.summary) AS supersedes, collect(DISTINCT new.summary) AS superseded_by,
               collect(DISTINCT i.number) AS incidents
        ORDER BY d.date DESC LIMIT 10""", ids=ids)
    return ev, bool(ent)


def ask(question):
    ev, entity_hit = retrieve(question)
    refusal = {"answer": "I can't answer this: the graph holds no recorded decision about it. "
                         "I won't guess.", "confidence": 0.0, "evidence": []}
    if not ev:
        return refusal
    out = chat_json(ANSWER_SYS, f"QUESTION: {question}\nEVIDENCE:\n{json.dumps(ev, indent=1)}")
    if not out.get("answerable"):
        return refusal
    cited = [e for e in ev if e["id"] in out.get("cited_ids", [])] or ev[:1]
    grounded = sum(1 for e in cited if e["url"] and e["person"])
    conf = min(0.95, 0.30 + 0.15 * min(len(cited), 3) + 0.10 * (grounded > 0) + 0.10 * entity_hit)
    return {"answer": out["answer"], "confidence": round(conf, 2), "evidence": cited}


if __name__ == "__main__":
    r = ask(" ".join(sys.argv[1:]))
    print(f"\n{r['answer']}\n\nConfidence: {r['confidence']:.0%}")
    for e in r["evidence"]:
        print(f"- [{e['date'][:10]}] {e['summary']} | {e['source']} | ask: {e['person']} | {e['url']}"
              + (f" | SUPERSEDED by: {e['superseded_by']}" if e["superseded_by"] else ""))
