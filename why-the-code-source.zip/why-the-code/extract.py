"""Step 2: turn raw sources into Decision nodes, then detect supersession.
Usage: python extract.py [--limit 300]"""
import argparse, hashlib
from common import run, chat_json

EXTRACT_SYS = """You extract engineering DECISIONS from commit messages, PR/issue discussions and design docs.
A decision is a deliberate choice with a reason (why a limit, a flag, a design, a migration was chosen or avoided).
Ignore routine changes (typos, version bumps, formatting). Never invent reasons that are not in the text.
Reply with JSON only: {"decisions":[{"summary":"...","rationale":"...","targets":[{"kind":"file|function|module|config","name":"..."}]}]}
Use {"decisions":[]} if there is none."""

SUPERSEDE_SYS = """Given an OLDER and a NEWER engineering decision about the same code entity, does the NEWER one
reverse, replace or invalidate the OLDER one? Reply with JSON only: {"overrides":true|false,"reason":"..."}"""


def extract(limit):
    srcs = run("""MATCH (s:Source) WHERE s.extracted IS NULL AND size(s.text) > 40
                  RETURN s.sid AS sid, s.title AS title, s.text AS text LIMIT $l""", l=limit)
    for s in srcs:
        out = chat_json(EXTRACT_SYS, f"TITLE: {s['title']}\nTEXT:\n{s['text']}")
        for d in out.get("decisions", []):
            if not d.get("summary"):
                continue
            did = hashlib.sha1((s["sid"] + d["summary"]).encode()).hexdigest()[:12]
            targets = [t for t in d.get("targets", []) if t.get("name") and t.get("kind")]
            run("""
            MATCH (s:Source {sid:$sid})
            MERGE (d:Decision {id:$id}) SET d.summary=$summary, d.rationale=$why, d.date=s.date, d.status='active'
            MERGE (d)-[:DECIDED_IN]->(s)
            WITH d, s
            OPTIONAL MATCH (p:Person)-[:AUTHORED]->(s)
            FOREACH (_ IN CASE WHEN p IS NULL THEN [] ELSE [1] END | MERGE (d)-[:MADE_BY]->(p))
            WITH d
            UNWIND $targets AS t
            MERGE (e:Entity {key:t.kind+':'+t.name}) SET e.name=t.name, e.kind=t.kind
            MERGE (d)-[:AFFECTS]->(e)""",
                sid=s["sid"], id=did, summary=d["summary"], why=d.get("rationale", ""), targets=targets)
            run("""MATCH (d:Decision {id:$id})-[:DECIDED_IN]->(s:Source)-[:FIXES|REFERENCES]->(i:Issue {is_incident:true})
                   MERGE (d)-[:TRIGGERED_BY]->(i)""", id=did)
        run("MATCH (s:Source {sid:$sid}) SET s.extracted=true", sid=s["sid"])
    print(f"extracted from {len(srcs)} sources")


def supersede():
    groups = run("""MATCH (e:Entity)<-[:AFFECTS]-(d:Decision)
        WITH e, d ORDER BY d.date
        WITH e, collect(d) AS ds WHERE size(ds) > 1
        RETURN e.key AS key, [x IN ds | {id:x.id, summary:x.summary, why:x.rationale, date:toString(x.date)}] AS ds""")
    n = 0
    for g in groups:
        for old, new in zip(g["ds"], g["ds"][1:]):
            out = chat_json(SUPERSEDE_SYS, f"ENTITY: {g['key']}\nOLDER ({old['date']}): {old['summary']} | {old['why']}\n"
                                           f"NEWER ({new['date']}): {new['summary']} | {new['why']}")
            if out.get("overrides"):
                run("""MATCH (n:Decision {id:$n}), (o:Decision {id:$o})
                       MERGE (n)-[r:SUPERSEDES]->(o) SET r.reason=$r, o.status='superseded'""",
                    n=new["id"], o=old["id"], r=out.get("reason", ""))
                n += 1
    print(f"supersession links: {n}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=300)
    a = ap.parse_args()
    extract(a.limit)
    supersede()
