import streamlit as st
from ask import ask

st.set_page_config(page_title="Why The Code Is Like This", page_icon="🧭")
st.title("🧭 Why The Code Is Like This")
st.caption("Decision-aware answers from a Neo4j knowledge graph of a repository's history.")
q = st.text_input("Ask about the codebase", placeholder="Why is the retry limit three?")
if q:
    with st.spinner("Walking the graph..."):
        r = ask(q)
    st.subheader("Answer")
    st.write(r["answer"])
    st.progress(r["confidence"], text=f"Confidence: {r['confidence']:.0%}")
    for e in r["evidence"]:
        status = "🟥 superseded" if e["superseded_by"] else "🟩 current"
        with st.expander(f"{status} · {e['date'][:10]} · {e['summary'][:80]}"):
            st.write(f"**Why:** {e['rationale']}")
            st.write(f"**Discussion:** [{e['source']}]({e['url']})")
            st.write(f"**Person to ask:** {e['person']}")
            if e["incidents"]:
                st.write(f"**Triggered by incident(s):** {e['incidents']}")
            if e["superseded_by"]:
                st.warning(f"Overridden by: {e['superseded_by']}")
            if e["supersedes"]:
                st.info(f"Replaced earlier decision: {e['supersedes']}")
